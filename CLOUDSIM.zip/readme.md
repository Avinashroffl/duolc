CLOUD SIM
reference link:https://www.cloudsimtutorials.online/cloudsim-setup-using-eclipse/
download links:https://github.com/Cloudslab/cloudsim/releases/tag/5.0
https://commons.apache.org/proper/commons-math/download_math.cgi
https://drive.google.com/file/d/1vYW_aKnQcNIXQihwZ3ZyWFP7L8udvWE8/view?usp=sharing
eclipse for java developers: Kepler Service Release 1
jre is 1.8.0
compiler compliance level is 1.7
java se 1.7 shoulod be used while creating project

example cloudsim basic steps: (datacenter with 1 hosts and 2 cloudlets)ex2
1.init cloudsim package
2.create datacenters
3.create broker
4.create vm
5.create cloudlets
6.start simulation
7.print results
