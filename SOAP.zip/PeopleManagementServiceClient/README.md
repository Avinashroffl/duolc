# PeopleManagementServiceClient
PeopleManagementServiceClient
To Generate Java files from WSDL, you can use below command
1. Open CMD:
2. wsimport -keep http://localhost:8080/PeopleManagementService/services/PeopleImpl?wsdl
