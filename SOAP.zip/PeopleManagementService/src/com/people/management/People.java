package com.people.management;

public interface People {
	public void setName(String name);
	public String getName();
	public int getAge();
}
