register app in https://github.com/settings/applications/new
http://localhost:2400/  homepage url 
http://localhost:2400/github/callback  callback url
npm init
npm install express ejs axios --save

express: Node.js framework to create a server and accept requests
ejs: To render HTML pages for login and profile
axios: Use the Axios library, to make HTTP requests

index.js change clientID, clientSecret
create files in views/pages/index.ejs and success.ejs

RUN NODE INDEX.JS

reference link: https://www.loginradius.com/blog/engineering/oauth-implemenation-using-node/

