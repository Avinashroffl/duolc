@javax.xml.bind.annotation.XmlSchema(namespace = "http://management.people.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.people.management;
