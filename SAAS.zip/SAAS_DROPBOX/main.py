# https://medium.com/@malikalbeik/how-to-periodically-backup-a-file-to-dropbox-using-python-and-cron-jobs-82ce2fdb97a3

import sys
import dropbox
from dropbox.files import WriteMode
from dropbox.exceptions import ApiError, AuthError
import datetime

dt = datetime.datetime.today()
TOKEN = 'sl.BJisDMP944WB-XKW3ai31pX80JlTkk-QHcpKQKkgEH_90zPn9btbSwoHFl-cH1O73vO5ecBCAkI3ZCWjsU9pSJfIrQu1kQBi7INZlZSlM9zjEu8732KCcYELWgynRKX1JUgOc-l0pt0'
LOCALFILE = 'C:\\Users\\rajna\\Downloads\\Master Students List.xlsx'
# Don't forget to add the file extension at the end of BACKUPPATH.
BACKUPPATH = '/MasterDB.xlsx'


def backup(localFile, backupPath):
    with open(localFile, 'rb') as f:
        # We use WriteMode=overwrite to make sure that the settings in the file
        # are changed on upload
        print("Uploading " + localFile + " to Dropbox as " + backupPath + "...")
        try:
            dbx.files_upload(f.read(), backupPath, mode=WriteMode('overwrite'))
        except ApiError as err:
            # This checks for the specific error where a user doesn't have
            # enough Dropbox space quota to upload this file
            if (err.error.is_path() and
                    err.error.get_path().reason.is_insufficient_space()):
                sys.exit("ERROR: Cannot back up; insufficient space.")
            elif err.user_message_text:
                print(err.user_message_text)
                sys.exit()
            else:
                print(err)
                sys.exit()


if __name__ == '__main__':
    # Create an instance of a Dropbox class, which can make requests to the API.
    print("Creating a Dropbox object...")
    dbx = dropbox.Dropbox(TOKEN)

    # Check that the access token is valid
    try:
        dbx.users_get_current_account()
    except AuthError:
        sys.exit("ERROR: Invalid access token; try re-generating an "
                 "access token from the app console on the web.")

    # Create a backup of the current settings file
    backup(LOCALFILE, BACKUPPATH)

    print("Done!")
