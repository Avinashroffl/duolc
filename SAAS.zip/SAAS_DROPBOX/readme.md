SAAS

open https://www.dropbox.com/developers/apps/
click create app
scoped access
full dropbox
give it a name
in permissions update (check all in account info and files and folders)
generate token and change in the main.py
change location of the file in main.py and destination file name

pip install dropbox
python file name to run the code
