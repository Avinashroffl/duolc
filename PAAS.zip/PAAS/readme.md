https://cloud.ibm.com/login
login->open cloud foundry
click create
enter app name
then click create
now app is created and getting started is displayed
choose delivery pipeline in overview
in delivery pipeline generate ibm cloud api key
now if u need to modify code, do it in eclipse orion web ide
CLICK DIAMOND ICON AND COMMIT CHANGES
THEN PUSH
if in continuous delivery, we got stage passed in deploy stage , then we have done with it